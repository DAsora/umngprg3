/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectibiris;




class Evaluar {

    // Método que recibe una cadena con una operación y devuelve su valor numérico
    public static double evaluar(String operacion) {
        // Eliminamos los espacios en blanco de la cadena
        operacion = operacion.replaceAll("\\s+", "");

        // Si la cadena está vacía, devolvemos 0
        if (operacion.isEmpty()) {
            return 0;
        }

        // Si la cadena empieza por un signo negativo, lo tratamos como un reesta
        if (operacion.startsWith("-")) {
            return -evaluar(operacion.substring(1));
        }

        // Buscamos el primer signo de suma o resta que no esté entre paréntesis
        int nivel = 0; // Nivel de anidamiento de los paréntesis
        for (int i = 0; i < operacion.length(); i++) {
            char c = operacion.charAt(i);
            if (c == '(') {
                nivel++;
            } else if (c == ')') {
                nivel--;
            } else if (nivel == 0 && (c == '+' || c == '-')) {
                // Si encontramos un signo de suma o resta, dividimos la cadena en dos partes
                String izquierda = operacion.substring(0, i);
                String derecha = operacion.substring(i + 1);
                // Evaluamos cada parte recursivamente y aplicamos la operación correspondiente
                if (c == '+') {
                    return evaluar(izquierda) + evaluar(derecha);
                } else {
                    return evaluar(izquierda) - evaluar(derecha);
                }
            }
        }

        // o de multiplicación o división que no esté entre paréntesis
        for (int i = 0; i < operacion.length(); i++) {
            char c = operacion.charAt(i);
            if (c == '(') {
                nivel++;
            } else if (c == ')') {
                nivel--;
            } else if (nivel == 0 && (c == '*' || c == '/')) {
                // , dividimos la cadena en dos partes
                String izquierda = operacion.substring(0, i);
                String derecha = operacion.substring(i + 1);
                // Evaluamos cada parte recursivamente y aplicamos 
                if (c == '*') {
                    return evaluar(izquierda) * evaluar(derecha);
                } else {
                    // Si la división es por cero, mostramos un  y devolvemos NaN
                    double divisor = evaluar(derecha);
                    if (divisor == 0) {
                        System.out.println("No se puede dividir por cero");
                        
                        
                        
                        return Double.NaN;
                        
                        
                        
                    } else {
                        return evaluar(izquierda) / divisor;
                    }
                }
            }
        }

        // Si no hay signos de multiplicación o división, buscamos el primer signo de potencia que no esté entre paréntesis
        for (int i = 0; i < operacion.length(); i++) {
            char c = operacion.charAt(i);
            if (c == '(') {
                nivel++;
            } else if (c == ')') {
                nivel--;
            } else if (nivel == 0 && c == '^') {
                // Si encontramos un signo de potencia, dividimos la cadena en dos partes
                String izquierda = operacion.substring(0, i);
                String derecha = operacion.substring(i + 1);
                // Evaluamos cada parte recursivamente y aplicamos la operación correspondiente
                return Math.pow(evaluar(izquierda), evaluar(derecha));
            }
        }

        // Si no hay signos de potencia, buscamos el primer paréntesis que abra
        int indiceParentesis = operacion.indexOf('(');
        if (indiceParentesis != -1) {
            // Si hay un paréntesis que abre, buscamos el paréntesis que cierra que coincida con él
            int indiceCierre = indiceParentesis + 1;
            nivel = 1;
            while (nivel > 0 && indiceCierre < operacion.length()) {
                char c = operacion.charAt(indiceCierre);
                if (c == '(') {
                    nivel++;
                } else if (c == ')') {
                    nivel--;
                }
                indiceCierre++;
            }
            // Si no encontramos el paréntesis que cierra, mostramos un mensaje de error y devolvemos NaN
            if (nivel > 0) {
                System.out.println("Falta un paréntesis que cierra");
                
                return Double.NaN;
            }
            // Si encontramos el paréntesis que cierra, extraemos la subcadena entre los paréntesis
            String dentro = operacion.substring(indiceParentesis + 1, indiceCierre - 1);
            // Evaluamos la subcadena recursivamente y la reemplazamos en la cadena original
            double valor = evaluar(dentro);
            operacion = operacion.substring(0, indiceParentesis) + valor + operacion.substring(indiceCierre);
            // Evaluamos la nueva cadena recursivamente
            return evaluar(operacion);
        }

        // Si no hay ningún paréntesis, intentamos convertir la cadena en un número
        try {
            return Double.parseDouble(operacion);
        } catch (NumberFormatException e) {
            // Si la conversión falla, mostramos un mensaje de error y devolvemos NaN
            System.out.println("No se reconoce el valor: " + operacion);
            
            return Double.NaN;
            
            
            
            
        }
    }
    
}
