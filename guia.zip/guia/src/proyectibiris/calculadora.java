
package proyectibiris;

public class calculadora {
    
    public double a,b,c,k,l,ñ;
    
    
    public void suma(){
        c=a+b;
    }
    
    public void resta(){
        c=a-b;
    }
    
    public void multiplicacion(){
        c=a*b;
    }
    
    public void division(){
        c=a/b;
    }
    
    public void seno(){
        a=Math.toRadians(a);
        c = Math.sin(a);
        c=Math.round(c);
//        c=Math.toDegrees(a);
    }
    
    public void coseno(){
        a=Math.toRadians(a);
        c = Math.cos(a);
c=Math.round(c);
    }
    
    public void tangente(){
         a=Math.toRadians(a);
        c = Math.tan(a);
        c=(int)Math.round(c);
    }
    
    public void raiz(){
      //  c = Math.sqrt(a);
        
        k=Math.pow(ñ,1/ l);
        
     
        
    }
    
    public void exponente(){
        c = Math.pow(a, b);
    }
    
    public void IVA(){
        c = (19*a)/100;
    }

   
   
}
        