
package proyectibiris;

import java.util.Scanner;


public class Proyectibiris {

    
    public static void main(String[] args) {
       System.out.println("Hola Mundo ...");
       Scanner objetoIn=new Scanner(System.in);
       
       
       
       System.out.println("ingrese el primer numero");
       int num1=objetoIn.nextInt();
       System.out.println("ingrese el segundo numero");
       int num2=objetoIn.nextInt();
       
       
       int resultado=num1+num2;
        System.out.println("el Resultado es  :"+resultado);
        
        Scanner sc =new Scanner(System.in);
        System.out.println("ingresa una Suma");
        int sume=sc.nextInt();
      
       sume =sume*1;
        System.out.println(sume);
       // texto3.setText(String.valueOf(T3));
        
        
        
        
        
    }
    
}
